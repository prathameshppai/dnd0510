package com.capgemini.dnd.customexceptions;

public class ConnectionException extends Exception {

	private static final long serialVersionUID = 8808593824473014733L;

	public ConnectionException(String message) {
		super(message);
	}

}
