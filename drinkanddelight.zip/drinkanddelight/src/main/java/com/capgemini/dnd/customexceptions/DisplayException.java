package com.capgemini.dnd.customexceptions;

public class DisplayException extends Exception {
	private static final long serialVersionUID = -528493360515655981L;

	public DisplayException(String message) {
		super(message);
	}

}
