package com.capgemini.dnd.customexceptions;

public class RowNotFoundException extends Exception {	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3372617756077752277L;

	public RowNotFoundException(String message) {
		super(message);

	}
}
