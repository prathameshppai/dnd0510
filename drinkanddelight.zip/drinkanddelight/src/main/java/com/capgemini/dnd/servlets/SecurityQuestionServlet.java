package com.capgemini.dnd.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.BackEndException;
import com.capgemini.dnd.customexceptions.InvalidPasswordException;
import com.capgemini.dnd.customexceptions.PasswordException;
import com.capgemini.dnd.customexceptions.PasswordMismatchException;
import com.capgemini.dnd.customexceptions.RowNotFoundException;
import com.capgemini.dnd.customexceptions.UnregisteredEmployeeException;
import com.capgemini.dnd.customexceptions.WrongSecurityAnswerException;
import com.capgemini.dnd.dao.Constants;
import com.capgemini.dnd.dto.Employee;
import com.capgemini.dnd.service.EmployeeService;
import com.capgemini.dnd.service.EmployeeServiceImpl;

public class SecurityQuestionServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7888060854228943686L;

	public SecurityQuestionServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Employee actualEmployee = new Employee();
		Employee idealEmployee = (Employee)request.getAttribute("passedEmployee");
		
		actualEmployee.setUsername(idealEmployee.getUsername());
		actualEmployee.setSecurityAnswer(request.getParameter("securityAnswer"));
		actualEmployee.setPassword(request.getParameter("password"));
		actualEmployee.setConfirmPassword(request.getParameter("confirmPassword"));

		EmployeeService employeeService = new EmployeeServiceImpl();
		
		try {
			if (employeeService.changePassword(idealEmployee, actualEmployee)) {
				response.getWriter().write("Yayy " + actualEmployee.getUsername() + "!! Password changed successfully");
				RequestDispatcher rd = request.getRequestDispatcher("/loginpage.html");
				rd.include(request, response);
			}
		} catch (UnregisteredEmployeeException | WrongSecurityAnswerException | PasswordException | BackEndException
				| InvalidPasswordException exception) {
			response.getWriter().write(exception.getMessage());
			RequestDispatcher rd = request.getRequestDispatcher("ForgotPasswordServlet");
			rd.include(request, response);
		}

	}

}
