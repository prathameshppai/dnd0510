package com.capgemini.dnd.util;

import org.apache.log4j.PropertyConfigurator;

public class Log4JManager {

	public static void initProps() {
		//PropertyConfigurator.configure("log4j.properties");

	}
}
