package com.capgemini.dnd.customexceptions;

public class ProcessDateException extends Exception {

	private static final long serialVersionUID = 6790172003318831067L;

	
	public ProcessDateException() {
	}

	public ProcessDateException(String message) {
		super(message);
	}


}
