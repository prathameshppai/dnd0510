package com.capgemini.dnd.customexceptions;

public class UpdateException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1257029051268478862L;

	public UpdateException(String message) 
	{	
		super(message);
	}
}
