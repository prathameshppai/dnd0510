package com.capgemini.dnd.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.InvalidEmailIdException;
import com.capgemini.dnd.customexceptions.PhoneNoException;
import com.capgemini.dnd.dto.Employee;
import com.capgemini.dnd.service.EmployeeService;
import com.capgemini.dnd.service.EmployeeServiceImpl;
import com.capgemini.dnd.util.InputValidator;

/**
 * Servlet implementation class RegistrationPageServlet
 */
public class RegistrationPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationPageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		Employee employee = new Employee();
		String errorMessage = "";
		String employeeName=request.getParameter("EmployeeName");
		//	Name should not contain number or special char
		String designation =request.getParameter("Designation");//	Manager,Asst. Manager, employee
		
		String emailId=null;
		
		try {
			emailId=request.getParameter("EmailID");
			InputValidator.emailIdValidator(emailId);
			employee.setEmailId(emailId);
		} catch (InvalidEmailIdException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
			
		String phoneNumber=null;
		try {
			phoneNumber=request.getParameter("PhoneNumber");
			InputValidator.phoneNoValidator(phoneNumber);
			employee.setPhoneNo(phoneNumber);
		} catch (PhoneNoException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
		
		String dobStr=request.getParameter("DOB");
		//restrict date in input html
		
		String gender=request.getParameter("gender");
		
		String userName=null;
		
		userName=request.getParameter("UserName");
		//username validation
		
		String password=request.getParameter("Password");
		String confirmPassword=request.getParameter("ConfirmPwd");
		//Password validation - min 8 char,....
		response.getWriter().write(errorMessage);
//		response.getWriter().write(employeeName + " " + designation + " " + emailId + " " + phoneNumber + " " + dobStr + " " + gender + " " + userName + " " + password + " " + confirmPwd);
		
		
	}

}
