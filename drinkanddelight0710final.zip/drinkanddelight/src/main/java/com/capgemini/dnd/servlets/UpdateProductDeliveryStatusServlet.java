package com.capgemini.dnd.servlets;

 

import java.io.IOException;

 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

import com.capgemini.dnd.service.ProductService;
import com.capgemini.dnd.service.ProductServiceImpl;
import com.capgemini.dnd.validator.InitializationValidator;

 

/**
 * Servlet implementation class UpdateProductDeliveryStatusServlet
 */
public class UpdateProductDeliveryStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProductDeliveryStatusServlet() {
        super();
        
    }

 

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

 

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        ProductService productService=new ProductServiceImpl();
        RequestDispatcher requestDispatcher=null;
        String orderId=request.getParameter("OrderId");
        String newDeliveryStatus=request.getParameter("DeliveryStatus");
        try {
            if(InitializationValidator.deliveryProductOrderStatusValidator(newDeliveryStatus)) {
                productService.updateStatusProductOrder(orderId, newDeliveryStatus);
                response.getWriter().write("Delivery Status successfully updated.");
                requestDispatcher=request.getRequestDispatcher("./homepage.html");
                requestDispatcher.forward(request, response);
            }
        } catch (Exception exception) {
            response.getWriter().write(exception.getMessage());
            requestDispatcher=request.getRequestDispatcher("/UpdateProductDeliveryStatus.html");
            requestDispatcher.include(request, response);
        }
    }

 

}