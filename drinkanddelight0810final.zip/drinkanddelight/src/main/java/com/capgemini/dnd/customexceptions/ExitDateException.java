package com.capgemini.dnd.customexceptions;

public class ExitDateException extends Exception {

	private static final long serialVersionUID = -6007825156697788887L;

	public ExitDateException() {
		// TODO Auto-generated constructor stub
	}

	public ExitDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
