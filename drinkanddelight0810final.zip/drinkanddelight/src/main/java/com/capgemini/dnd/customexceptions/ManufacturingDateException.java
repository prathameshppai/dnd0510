package com.capgemini.dnd.customexceptions;

public class ManufacturingDateException extends Exception {

	private static final long serialVersionUID = 448573056305955059L;

	public ManufacturingDateException() {
		// TODO Auto-generated constructor stub
	}

	public ManufacturingDateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



}
