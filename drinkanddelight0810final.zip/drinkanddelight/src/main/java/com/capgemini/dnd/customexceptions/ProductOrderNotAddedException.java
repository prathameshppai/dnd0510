package com.capgemini.dnd.customexceptions;

public class ProductOrderNotAddedException extends Exception {

	public ProductOrderNotAddedException() {
	}

	public ProductOrderNotAddedException(String message) {
		super(message);
	}


}
