package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.ProductOrderNotAddedException;
import com.capgemini.dnd.dao.Constants;
import com.capgemini.dnd.dto.ProductOrder;
import com.capgemini.dnd.service.ProductService;
import com.capgemini.dnd.service.ProductServiceImpl;

public class PlaceProductOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1028319732394752L;

	public PlaceProductOrderServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
		ProductService productService = new ProductServiceImpl();
		String errorMessage = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String productName = request.getParameter("ProductName");
		String pid = request.getParameter("PSID");
		String distributorId = request.getParameter("DID");

		double quantityValue = 0;
		try {
			quantityValue = Double.parseDouble(request.getParameter("Quantity"));
		} catch (NumberFormatException exception) {
			errorMessage += "<br>Enter quantity in decimal";
		}

		String quantityUnit = request.getParameter("QuantityUnit");
		LocalDate localDate = LocalDate.now();
		Date today = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		Date expectedDateofDelivery = null;
		try {
			expectedDateofDelivery = sdf.parse(request.getParameter("expectedDateofDelivery"));
		} catch (ParseException e) {
			errorMessage += "<br>" + Constants.PARSE_EXCEPTION_INVALID_FORMAT;
		}

		double price_per_unit = 0;
		try {
			price_per_unit = Double.parseDouble(request.getParameter("price_per_unit"));
		} catch (NumberFormatException exception) {
			errorMessage += "<br>Enter Price per Unit in decimal";
		}

		String warehouseId = request.getParameter("warehouseId");

		try {
			if (errorMessage.isEmpty()) {
				ProductOrder productOrder = new ProductOrder(productName, pid, distributorId, quantityValue,
						quantityUnit, today, expectedDateofDelivery, price_per_unit, warehouseId);

				productService.placeProductOrder(productOrder);
				response.getWriter().write("Order placed successfully");
				RequestDispatcher rd = request.getRequestDispatcher("/PlaceProductOrder.html");
				rd.include(request, response);
			} else {
				response.getWriter().write(errorMessage);
				RequestDispatcher rd = request.getRequestDispatcher("/PlaceProductOrder.html");
				rd.include(request, response);
			}

		} catch (ProductOrderNotAddedException | ConnectionException | SQLException exception) {
			errorMessage += exception.getMessage();
			response.getWriter().write(errorMessage);
			RequestDispatcher rd = request.getRequestDispatcher("/PlaceProductOrder.html");
			rd.include(request, response);
		}

		response.getWriter().write(errorMessage);
	}
}