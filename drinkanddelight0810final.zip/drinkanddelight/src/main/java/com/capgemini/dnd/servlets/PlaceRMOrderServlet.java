package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.RMOrderNotAddedException;
import com.capgemini.dnd.dao.Constants;
import com.capgemini.dnd.dto.RawMaterialOrder;
import com.capgemini.dnd.service.RawMaterialService;
import com.capgemini.dnd.service.RawMaterialServiceImpl;

public class PlaceRMOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public PlaceRMOrderServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		HttpSession session = request.getSession();
		if(session.getAttribute("username") == null) {
			RequestDispatcher rd = request.getRequestDispatcher("/loginpage.html");
			rd.include(request, response);
		}
			
		RawMaterialService rawMaterialService = new RawMaterialServiceImpl();
		String errorMessage = "";
		doGet(request, response);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String rawMaterialName = request.getParameter("RMName");
		String rmId = request.getParameter("RMID");
		String supplierId = request.getParameter("SUPID");

		double quantity = 0;
		try {
			quantity = Double.parseDouble(request.getParameter("Quantity"));
		} catch (NumberFormatException exception) {
			errorMessage += "<br>Enter quantity in decimal";
		}

		String quantityUnit = request.getParameter("QuantityUnit");
		LocalDate localDate = LocalDate.now();
		Date today = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());

		Date expectedDateofDelivery = null;
		try {
			expectedDateofDelivery = sdf.parse(request.getParameter("expectedDateofDelivery"));
		} catch (ParseException e) {
			errorMessage += "<br>" + Constants.PARSE_EXCEPTION_INVALID_FORMAT;
		}

		double price_per_unit = 0;
		try {
			price_per_unit = Double.parseDouble(request.getParameter("price_per_unit"));
		} catch (NumberFormatException exception) {
			errorMessage += "<br>Enter Price per Unit in decimal";
		}
		String warehouseId = request.getParameter("warehouseId");
		
		try {
			if (errorMessage.isEmpty()) {
				RawMaterialOrder rawMaterialOrder = new RawMaterialOrder(rawMaterialName, rmId, supplierId, quantity, quantityUnit,
						today, expectedDateofDelivery, price_per_unit, warehouseId);
				rawMaterialService.placeRawMaterialOrder(rawMaterialOrder);
				response.getWriter().write("Order placed successfully");
				RequestDispatcher rd=request.getRequestDispatcher("/PlaceRMOrder.html");
				rd.include(request, response);
			}
			else {
				response.getWriter().write("try");//errorMessage);
				RequestDispatcher rd=request.getRequestDispatcher("/PlaceRMOrder.html");
				rd.include(request, response);
			}
			
		} catch (RMOrderNotAddedException | ConnectionException | SQLException exception) {
			errorMessage += exception.getMessage();
			response.getWriter().write(errorMessage);
			RequestDispatcher rd=request.getRequestDispatcher("/PlaceRMOrder.html");
			rd.include(request, response);
		}
	}	
}
