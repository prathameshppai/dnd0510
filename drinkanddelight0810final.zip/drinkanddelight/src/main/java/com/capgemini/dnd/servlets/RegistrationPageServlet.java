package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.FullNameException;
import com.capgemini.dnd.customexceptions.InvalidEmailIdException;
import com.capgemini.dnd.customexceptions.InvalidPasswordException;
import com.capgemini.dnd.customexceptions.PhoneNoException;
import com.capgemini.dnd.customexceptions.UserNameException;
import com.capgemini.dnd.dao.Constants;
import com.capgemini.dnd.dto.Employee;
import com.capgemini.dnd.service.EmployeeService;
import com.capgemini.dnd.service.EmployeeServiceImpl;
import com.capgemini.dnd.util.InputValidator;

public class RegistrationPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistrationPageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
		EmployeeService employeeService = new EmployeeServiceImpl();
		Employee employee = new Employee();
		String errorMessage = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String employeeName=null;
		try {
			employeeName=request.getParameter("EmployeeName");
			InputValidator.fullNameValidator(employeeName);
			employee.setEmpName(employeeName);
		} catch (FullNameException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
		
		String designation =request.getParameter("Designation");
		
		String emailId=null;
		try {
			emailId=request.getParameter("EmailID");
			InputValidator.emailIdValidator(emailId);
			employee.setEmailId(emailId);
		} catch (InvalidEmailIdException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
			
		String phoneNumber=null;
		try {
			phoneNumber=request.getParameter("PhoneNumber");
			InputValidator.phoneNoValidator(phoneNumber);
			employee.setPhoneNo(phoneNumber);
		} catch (PhoneNoException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
		
		Date dateOfBirth = null;
		try {
			dateOfBirth = sdf.parse(request.getParameter("DOB"));
			Date minDate = sdf.parse("2000-01-01");
			if(dateOfBirth.before(minDate ))
				employee.setDob((java.sql.Date) dateOfBirth);
			else
				errorMessage += "<br>Please enter valid date of birth";
		} catch (ParseException e) {
			errorMessage += "<br>" + Constants.PARSE_EXCEPTION_INVALID_FORMAT;
		}
		
		
		String dobStr=request.getParameter("DOB");
		
		String gender=request.getParameter("gender");
		employee.setGender(gender);
		
		String userName=null;
		try {
			userName=request.getParameter("UserName");
			InputValidator.userNameValidator(userName);
			employee.setUsername(userName);
		} catch (UserNameException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
		
		employee.setSecurityQuestion(request.getParameter("SecurityQues"));
		
		employee.setSecurityAnswer(request.getParameter("SecurityAns"));
		
		String password=null;
		try {
			password=request.getParameter("Password");
			InputValidator.passwordValidator(password);
			employee.setPassword(password);
		} catch (InvalidPasswordException exception) {
			errorMessage+="<br> " + exception.getMessage();
		}
		
		String confirmPassword=request.getParameter("ConfirmPwd");
		//Password validation - min 8 char,....
		
//		response.getWriter().write(employeeName + " " + designation + " " + emailId + " " + phoneNumber + " " + dobStr + " " + gender + " " + userName + " " + password + " " + confirmPwd);
		
		
		try {
			if (errorMessage.isEmpty()) {
				employeeService.register(employee);
				response.getWriter().write("Employee registered succesfully.");
				RequestDispatcher rd=request.getRequestDispatcher("/loginpage.html");
				rd.include(request, response);
			}	
		}catch(Exception exception) {
			response.getWriter().write(errorMessage);
			RequestDispatcher rd=request.getRequestDispatcher("/registrationPage.html");
			rd.include(request, response);
		}
		
	}

}
