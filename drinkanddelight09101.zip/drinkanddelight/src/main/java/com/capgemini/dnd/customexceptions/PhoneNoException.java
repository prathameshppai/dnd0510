package com.capgemini.dnd.customexceptions;

public class PhoneNoException extends Exception {
	private static final long serialVersionUID = 4733241463777650191L;

	public PhoneNoException(String message) {
		super(message);
	}
}
