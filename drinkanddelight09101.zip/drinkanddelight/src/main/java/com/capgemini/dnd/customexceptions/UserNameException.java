package com.capgemini.dnd.customexceptions;

public class UserNameException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8133810375094147784L;

	public UserNameException(String message) {
		super(message);
	}
}
