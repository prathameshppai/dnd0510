package com.capgemini.dnd.customexceptions;

public class InvalidDateFormatException extends Exception {

	private static final long serialVersionUID = -1344871363840185386L;

	public InvalidDateFormatException() {
		
	}

	public InvalidDateFormatException(String message) {
		super(message);
		
	}



}
