package com.capgemini.dnd.customexceptions;

public class RMIDDoesNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8709598585094928283L;

	/**
	 * 
	 */


	public RMIDDoesNotExistException() {
		
	}

	public RMIDDoesNotExistException(String message) {
		super(message);
		
	}



}
