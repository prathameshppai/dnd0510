package com.capgemini.dnd.customexceptions;

public class RMOrderNotAddedException extends Exception {

	public RMOrderNotAddedException() {
	}

	public RMOrderNotAddedException(String message) {
		super(message);
	}


}
