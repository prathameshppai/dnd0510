package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.ProductOrderIDDoesNotExistException;
import com.capgemini.dnd.customexceptions.RMOrderIDDoesNotExistException;
import com.capgemini.dnd.dto.ProductStock;
import com.capgemini.dnd.service.ProductService;
import com.capgemini.dnd.service.ProductServiceImpl;

public class TrackProductOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public TrackProductOrderServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		HttpSession session = request.getSession();
		if(session.getAttribute("username") == null) {
			RequestDispatcher rd = request.getRequestDispatcher("/loginpage.html");
			rd.include(request, response);
		}
		String id = request.getParameter("OrderId");
		ProductService productServiceObject = new ProductServiceImpl();
		
		try {
			if(productServiceObject.doesProductOrderIdExist(id)) {
				response.getWriter().write("<script> alert(\"" + productServiceObject.trackProductOrder(new ProductStock(id)) + "\")</script>");
				RequestDispatcher reqd=request.getRequestDispatcher("/trackProductOrder.html");  
			    reqd.include(request, response);
			}	
		} catch (ConnectionException | SQLException | ProductOrderIDDoesNotExistException exception) {
			response.getWriter().write("<script> alert(\"" + exception.getMessage() + "\")</script>");
			RequestDispatcher rd1=request.getRequestDispatcher("/trackProductOrder.html");
			rd1.include(request, response);
		}
	}
	}

