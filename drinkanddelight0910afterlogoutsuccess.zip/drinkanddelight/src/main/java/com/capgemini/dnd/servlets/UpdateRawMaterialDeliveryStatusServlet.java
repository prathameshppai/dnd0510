package com.capgemini.dnd.servlets;

 

import java.io.IOException;

 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

 

import com.capgemini.dnd.service.RawMaterialService;
import com.capgemini.dnd.service.RawMaterialServiceImpl;
import com.capgemini.dnd.validator.InitializationValidator;

 

/**
 * Servlet implementation class UpdateRMDeliveryStatusServlet
 */
public class UpdateRawMaterialDeliveryStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    Logger logger = Logger.getRootLogger();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateRawMaterialDeliveryStatusServlet() {
        super();
    }

 

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

 

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      		HttpSession session = request.getSession();
      		if(session.getAttribute("username") == null) {
      			RequestDispatcher rd = request.getRequestDispatcher("/loginpage.html");
      			rd.include(request, response);
      		}
        RawMaterialService rawMaterialService=new RawMaterialServiceImpl();
        String orderId=request.getParameter("OrderId");
        String newDeliveryStatus=request.getParameter("DeliveryStatus");
        try {
            if(InitializationValidator.deliveryRawMaterialOrderStatusValidator(newDeliveryStatus)) {
                rawMaterialService.updateStatusRawMaterialOrder(orderId, newDeliveryStatus);
//                response.getWriter().write("<script> alert(\"" + "Delivery Status successfully updated." + "\")</script>");
                response.getWriter().write("<h1 style=\"z-index:1000\">kbfdjhbv</h1>");
//                RequestDispatcher rd=request.getRequestDispatcher("/UpdateRawMaterialDeliveryStatus.html");
//                rd.forward(request, response);
            }
        } catch (Exception exception) {
        	response.getWriter().write("<script> alert(\"" + exception.getMessage() + "\")</script>");
            RequestDispatcher rd=request.getRequestDispatcher("/UpdateRawMaterialDeliveryStatus.html");
            rd.include(request, response);
        }
    }
}