package com.capgemini.dnd.customexceptions;

public class RowFetchException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2437929717006541034L;

	public RowFetchException(String message) {
		super(message);
	}
}
