package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.ExpiryDateException;
import com.capgemini.dnd.customexceptions.ManufacturingDateException;
import com.capgemini.dnd.customexceptions.ProductOrderIDDoesNotExistException;
import com.capgemini.dnd.dto.ProductStock;
import com.capgemini.dnd.service.ProductService;
import com.capgemini.dnd.service.ProductServiceImpl;


public class UpdateProductStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateProductStockServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		ProductService productServiceObject = new ProductServiceImpl();
		String errorMessage ="";
		
                      String OrderId= req.getParameter("OrderId");
                     // String ManufacturingDate= req.getParameter("ManufacturingDate");
                     // String  ExpiryDate= req.getParameter( "ExpiryDate");
                      
			boolean productOrderIdFound = false;
			try {
				productOrderIdFound = productServiceObject.doesProductOrderIdExist(OrderId);
			} catch (ProductOrderIDDoesNotExistException | ConnectionException | SQLException e) {
				errorMessage += "<br>" + e.getMessage();
			}

			Date ManufacturingDate = null;
			Date ExpiryDate = null;
			
			if (productOrderIdFound == true) {
				try {
					ManufacturingDate = sdf.parse(req.getParameter("ManufacturingDate"));
					productServiceObject.validateManufacturingDate(ManufacturingDate);
				} catch (ParseException e) {
					errorMessage += "<br>" + e.getMessage();

				} catch (ManufacturingDateException e) {
					errorMessage += "<br>" + e.getMessage();

				}

				try {
					ExpiryDate = sdf.parse(req.getParameter( "ExpiryDate"));
					productServiceObject.validateExpiryDate(ManufacturingDate, ExpiryDate);
				} catch (ParseException e) {
					errorMessage += "<br>" + e.getMessage();
				}

				catch (ExpiryDateException e) {
					errorMessage += "<br>" + e.getMessage();
				}
				
				 String QAStatus= req.getParameter("QAStatus");
				if (QAStatus.equalsIgnoreCase("passed") || QAStatus.equalsIgnoreCase("failed")) {
					String message = productServiceObject
							.updateProductStock(new ProductStock(OrderId, ManufacturingDate, ExpiryDate, QAStatus));
					res.getWriter().write(message);
					
				}
	}

			else {
				res.getWriter().write("Order ID doesnt exist");
				
			}
		}

}