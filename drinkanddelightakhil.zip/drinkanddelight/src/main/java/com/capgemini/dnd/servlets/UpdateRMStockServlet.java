package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.ExpiryDateException;
import com.capgemini.dnd.customexceptions.ManufacturingDateException;
import com.capgemini.dnd.customexceptions.RMOrderIDDoesNotExistException;
import com.capgemini.dnd.dto.RawMaterialStock;
import com.capgemini.dnd.service.RawMaterialService;
import com.capgemini.dnd.service.RawMaterialServiceImpl;


public class UpdateRMStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateRMStockServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

}

 protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
				
				doGet(req, res);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				RawMaterialService rawMaterialServiceObject = new RawMaterialServiceImpl();
				String errorMessage ="";
				
		                      String OrderId= req.getParameter("OrderId");
		                     // String ManufacturingDate= req.getParameter("ManufacturingDate");
		                     // String  ExpiryDate= req.getParameter( "ExpiryDate");
		                      
		                      boolean doesRMOrderIDexist = false;
					try {
						doesRMOrderIDexist = rawMaterialServiceObject.doesRawMaterialOrderIdExist(OrderId);
					} catch (RMOrderIDDoesNotExistException | ConnectionException | SQLException e) {
						errorMessage += "<br>" + e.getMessage();
					}

					Date ManufacturingDate = null;
					Date ExpiryDate = null;
					
					if (doesRMOrderIDexist == true) {
						try {
							ManufacturingDate = sdf.parse(req.getParameter("ManufacturingDate"));
							rawMaterialServiceObject.validateManufacturingDate(ManufacturingDate);
						}
						catch (ParseException e) {
							errorMessage += "<br>" + e.getMessage();

						}catch (ManufacturingDateException e) {
							errorMessage += "<br>" + e.getMessage();

						}

						try {
							ExpiryDate = sdf.parse(req.getParameter("ExpiryDate"));
							rawMaterialServiceObject.validateExpiryDate(ManufacturingDate, ExpiryDate);
						} catch (ParseException e) {
							errorMessage += "<br>" + e.getMessage();
						}

						catch (ExpiryDateException e) {
							errorMessage += "<br>" + e.getMessage();
						}
						
						 String QAStatus= req.getParameter("QAStatus");
						if (QAStatus.equalsIgnoreCase("passed") || QAStatus.equalsIgnoreCase("failed")) {
							String message = rawMaterialServiceObject.updateRMStock(new RawMaterialStock(OrderId, ManufacturingDate, ExpiryDate, QAStatus));
							res.getWriter().write(message);
							
						}
			}

					else {
						res.getWriter().write("Order ID doesnt exist");
						
					}
				}

	}



