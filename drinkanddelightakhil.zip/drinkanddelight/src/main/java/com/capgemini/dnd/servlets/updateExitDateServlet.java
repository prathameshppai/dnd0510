package com.capgemini.dnd.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.dnd.customexceptions.ConnectionException;
import com.capgemini.dnd.customexceptions.ExitDateException;
import com.capgemini.dnd.customexceptions.ProductOrderIDDoesNotExistException;
import com.capgemini.dnd.dto.ProductStock;
import com.capgemini.dnd.service.ProductService;
import com.capgemini.dnd.service.ProductServiceImpl;

public class updateExitDateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public updateExitDateServlet() {
        super();
    }
      
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		doGet(req, res);
		SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd");
		ProductService productServiceObject = new ProductServiceImpl();
		boolean pOrderIdFound = false;
		
		String errorMessage = "";
		
		String OrderId=req.getParameter("OrderId");
		try {
		
			pOrderIdFound = productServiceObject.doesProductOrderIdExist(OrderId);
		} catch (ProductOrderIDDoesNotExistException | ConnectionException | SQLException e) {

			errorMessage += "<br>" + e.getMessage();
			
		}
	
			    Date ExitDate =null;;
				try {
					ExitDate = sdf.parse(req.getParameter("ExitDate"));
				} catch (ParseException e) {
				
					errorMessage += "<br>" + e.getMessage(); 
				}
			    try {
				boolean dateCheck = productServiceObject.exitDateCheck(new ProductStock(OrderId, ExitDate));
				if (dateCheck == true) {
					String message = productServiceObject.updateExitDateinStock(new ProductStock(OrderId, ExitDate));
					res.getWriter().write(message);
					
				}
			    } 
			 catch (ExitDateException e) {
				 errorMessage += "<br>" + e.getMessage(); 
				}
            catch (ConnectionException | SQLException e) {
            	errorMessage += "<br>" + e.getMessage();
			}
			    
			    res.getWriter().write(errorMessage);

		} 

	}
