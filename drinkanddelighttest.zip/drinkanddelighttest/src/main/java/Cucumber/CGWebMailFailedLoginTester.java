package Cucumber;

import static org.junit.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CGWebMailFailedLoginTester {
	
	String chromeDriverPath = "C:\\Users\\ashwapan\\Documents\\chromedriver.exe";
	WebDriver driver = null;

	@Given("^I am on CG WebMail login page$")
	public void goToCGWebMailOnChrome() {
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		driver = new ChromeDriver();
		driver.navigate().to(
				"https://webmail.capgemini.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fwebmail.capgemini.com%2fowa%2f");
		System.out.println("Title: " + driver.getTitle());
	}

	@When("^I enter username as \"(.*)\"$")
	public void enterUsername(String arg1) {
		System.out.println(arg1);
		driver.findElement(By.id("username")).sendKeys(arg1);
	}

	@When("^I enter password as \"(.*)\"$")
	public void enterPassword(String arg1) {
		System.out.println(arg1);
		driver.findElement(By.id("password")).sendKeys(arg1);
		driver.findElement(By.name("logonForm")).submit();
	}

	@Then("^Login should fail$")
	public void checkFail() {
		if (driver.getCurrentUrl().contains("&reason=2")) {
			System.out.println("Test1 Pass");
		} else {
			System.out.println("Test1 Failed");
			System.out.println(driver.getCurrentUrl());
			fail("Login didn't fail");
		}
	}

	@Then("^Relogin option should be available$")
	public void checkRelogin() {
		if (driver.findElement(By.id("username")) != null && driver.findElement(By.id("password")) != null) {
			System.out.println("Test2 Pass");
		} else {
			System.out.println(driver.getCurrentUrl());
			System.out.println("Test2 Failed");
			fail("Relogin option not available");
		}
		// driver.close();
	}

	@After
	public void close() {
		System.out.println("Closing the driver.");
		if (driver != null) {
			driver.quit();
		}
	}
}